package dymn.simulator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import dymn.simulator.config.BaseWorker;
import dymn.simulator.tcp.TCPServer;

@SpringBootApplication(scanBasePackages={"dymn.simulator"})
//@MapperScan(value = "{dymn.demo}")
public class SimulatorApplication extends SpringBootServletInitializer {

	private static final Logger LOGGER = LoggerFactory.getLogger(SimulatorApplication.class);
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder  application) {
//		String home = System.getProperty("user.home");
//		LOGGER.info("PID File :: {}", home);
//		application.build().addListeners(new ApplicationPidFileWriter(home + File.separator + "startup.pid"));
		return application.sources(SimulatorApplication.class);
	}
	
	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SimulatorApplication.class, args);
		TCPServer tcpServer = context.getBean(TCPServer.class);
		tcpServer.start();
		BaseWorker baseWorker = context.getBean(BaseWorker.class);
		Thread thread = new Thread(baseWorker);
		thread.start();

		
//		ConfigurableApplicationContext context = new SpringApplicationBuilder(SimulatorApplication.class).web(WebApplicationType.NONE).run(args);
//		int exitCode = SpringApplication.exit(context, new ExitCodeGenerator() {
//
//			@Override
//			public int getExitCode() {
//				return 0;
//			}
//			
//		});
//		System.exit(exitCode);
//		ConfigurableApplicationContext context = SpringApplication.run(SimulatorApplication.class, args);
//		String home = System.getProperty("user.home");
//		LOGGER.info("PID File :: {}", home);
//		context.addApplicationListener(new ApplicationPidFileWriter(home + File.separator + "startup.pid"));
	}
	
//	@Bean
//	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
//		return args -> {
//            System.out.println("Let's inspect the beans provided by Spring Boot:");
//
//            String[] beanNames = ctx.getBeanDefinitionNames();
//            Arrays.sort(beanNames);
//            for (String beanName : beanNames) {
//                System.out.println(beanName);
//            }
//
//        };
//	}
//	@Bean
//	public SqlSessionFactory sqlSessionFactory(DataSource datasource) throws Exception {
//		SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
//		sessionFactory.setDataSource(datasource);
//		
//		Resource[] sqlResources = new PathMatchingResourcePatternResolver().getResources("classpath:sqlmap/**/*SQL.xml");
//		Resource configLocation = new PathMatchingResourcePatternResolver().getResource("classpath:sqlmap/config/mybatis-config.xml");
//		
//		sessionFactory.setConfigLocation(configLocation);
//		
//		sessionFactory.setMapperLocations(sqlResources);
//		
//		return sessionFactory.getObject();
//	}
}
