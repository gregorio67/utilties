
package dymn.simulator.util;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.DataBinder;

import dymn.simulator.base.CamelMap;
import dymn.simulator.exception.BizException;


public class MapUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(MapUtil.class);


	
	/**
	 * 
	 *<pre>
	 * 1.Description: Convert Map to String
	 * 2.Biz Logic:
	 * 3.Author : LGCNS
	 *</pre>
	 * @param map Map for converting String
	 * @return String 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static String toStringMap(Map map) {
		StringBuffer sb = new StringBuffer();
		
		if (map != null && map.size() > 0) {
			Set<String> keySet = map.keySet();
			
			Iterator<String> iter = keySet.iterator();
			
			int cnt = 1;
			
			while (iter.hasNext()) {
				String key = iter.next();
				Object value = map.get(key);
				
				sb.append(cnt + " : " + "Column Name=" + key + ", " 
						+ "Value=" + value.toString() 
						+ ", DataType=" + value.getClass().getName() 
						+ "\n");
				
				cnt++;
			}
		} else {
			sb.append("정보가 없습니다.");
		}
		
		return sb.toString();
	}	
	
	/** 
	 * Convert value object to map with value object instance
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public static<T> Map<String, Object> Vo2Map(final T vo) throws Exception {
		final Map<String, Object> resultMap = new HashMap<String, Object>();
	
		final Class<?> clazz = vo.getClass();
		ReflectionUtils.doWithFields(clazz, new ReflectionUtils.FieldCallback() {

			@Override
			public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
				ReflectionUtils.makeAccessible(field);
				String fieldName = field.getName();
				resultMap.put(fieldName, field.get(vo));
			}
			
		});
		
		return resultMap;
	}
	
	/**
	 * Convert Map to Value Object with value object instance
	 * @param map
	 * @param vo
	 * @throws Exception
	 */
	public static<V> void map2Vo(Map<String, Object> map, V vo) throws Exception {
		
		Iterator<String> itr = map.keySet().iterator();
		Class<?> clazz = vo.getClass();
		while(itr.hasNext()) {
			String key = itr.next();
			Field field = ReflectionUtils.findField(clazz, key);
			if (field != null) {
				ReflectionUtils.makeAccessible(field);
				setFieldValue(field, vo, map.get(key));			
			}
		}
	}
	
	public static<V> void map2Vo(MutablePropertyValues map, V vo) throws Exception {
		DataBinder binder = new DataBinder(vo);
		binder.bind(map);
	}	
	/**
	 * Convert map to value object with value object class
	 * @param map
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static<V> V map2Vo(Map<String, Object> map, Class<?> clazz) throws Exception {
		
		Iterator<String> itr = map.keySet().iterator();
		
		/** Instance class**/
		@SuppressWarnings("unchecked")
		V vo = (V) clazz.newInstance();
		
		while(itr.hasNext()) {
			String key = itr.next();
			Field field = ReflectionUtils.findField(clazz, key);
			if (field != null) {
				ReflectionUtils.makeAccessible(field);
				Object value = map.get(key);
				ReflectionUtils.setField(field, vo, value);
//				setFieldValue(field, vo, map.get(key));				
			}
		}
		
		return vo;
	}
	
	
	public static<V> V map2Vo(MutablePropertyValues map, Class<?> clazz) throws Exception {
		@SuppressWarnings("unchecked")
		V vo = (V) clazz.newInstance();
		DataBinder binder = new DataBinder(vo);
		binder.bind(map);
		
		return vo;
	}
	
	
	/** 
	 * Set filed value
	 * @param field
	 * @param vo
	 * @param fieldValue
	 * @throws Exception
	 */
	private static <V> void setFieldValue(Field field, V vo, Object fieldValue) throws Exception {
		
		ReflectionUtils.makeAccessible(field);
		
		if (field.getType() == int.class || field.getType() == Integer.class) {
			int value = fieldValue != null ? Integer.parseInt((String.valueOf(fieldValue))) : 0;
			ReflectionUtils.setField(field, vo, value);
		}
		else if (field.getType() == long.class || field.getType() == Long.class) {
			long value =fieldValue != null ? Long.parseLong((String.valueOf(fieldValue))) : 0;
			ReflectionUtils.setField(field, vo, value);
		}
		else if (field.getType() == float.class || field.getType() == Float.class) {
			float value = fieldValue != null ? Float.parseFloat((String.valueOf(fieldValue))) : 0;
			ReflectionUtils.setField(field, vo, value);
		}
		else if (field.getType() == double.class || field.getType() == Double.class) {
			double value =fieldValue != null ? Double.parseDouble((String.valueOf(fieldValue))) : 0;
			ReflectionUtils.setField(field, vo, value);
		}
		else {
			String value = fieldValue != null ? String.valueOf(fieldValue) : "";
			ReflectionUtils.setField(field, vo, value);
		}				
	}
	
	public static void map2File(String fileName, List<Map<String, Object>> source) throws Exception {
		map2File(fileName, source, true);
	}
	
	public static void map2File(String fileName, List<Map<String, Object>> source, boolean isHeader) throws Exception {
		
		if (fileName == null) {
			return;
		}
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(fileName));
		
		int idx = 0;
		int loop = 0;
		StringBuilder sbHeader = new StringBuilder();
		StringBuilder sbData = new StringBuilder();
		try {				
				for (Map<String, Object> map : source) {
				Iterator<String> itr = map.keySet().iterator();
				int size = map.size();
				if (idx == 0 && isHeader) {
					
					/** Create CSV column with result **/
					loop = 0;
					while(itr.hasNext()) {
						String key = itr.next();
						if (loop == (size - 1)) {
							sbHeader.append(key);
							sbData.append(map.get(key));
						}
						else {
							sbHeader.append(key).append(",");
							sbData.append(map.get(key)).append(",");
						}
						
						loop++;
					}
				}
				else {
					loop = 0;
					while(itr.hasNext()) {
						String key = itr.next();
						if (loop == (size - 1)) {
							sbData.append(map.get(key));
						}
						else {
							sbData.append(map.get(key)).append(",");
						}
						loop++;
					}
				}
				
				/** Write Header to file **/
				if (sbHeader.length() > 0) {
					sbHeader.append("\n");
					bos.write(sbHeader.toString().getBytes("UTF-8"));
//					sbHeader.delete(0, sbHeader.length() - 1);
					sbHeader.setLength(0);
				}
				
				/** Write Data to file **/
				if (sbData.length() > 0) {
					sbData.append("\n");
					bos.write(sbData.toString().getBytes("UTF-8"));				
//					sbData.delete(0, sbData.length() - 1);
					sbData.setLength(0);
				}
				
				idx++;
				bos.flush();
			}
		}
		catch (Exception ex) {
			LOGGER.error("Excel file creation error :: {}", ex.getMessage());
			throw new BizException("Excel file creation error");
		}
		finally {
			if (bos != null) bos.close();
		}						
	}
		
	

	/**
	 * 
	 *<pre>
	 * 1.Description: Copy input map to new map
	 * 2.Biz Logic: 
	 * 3.Author : LGCNS
	 *</pre>
	 * @param sourceMap map for copied
	 * @return Copied map is same the input map
	 * @throws Exception
	 */
	public static Map<String, Object> setMapToMap(Map<String, Object> sourceMap) throws Exception {
		Map<String, Object> targetMap = new HashMap<String, Object>();
		
		if (sourceMap != null && sourceMap.size() > 0) {
			Set<String> keySet = sourceMap.keySet();
			
			Iterator<String> iter = keySet.iterator();
			
			while (iter.hasNext()) {
				String key = iter.next();
				Object value = sourceMap.get(key);
				
				targetMap.put(key, value.toString());
			}
		}
		
		return targetMap != null && targetMap.size() > 0 ? targetMap : new HashMap<String, Object>();
	}
	
	/**
	 * 
	 *<pre>
	 * 1.Description: Merge target map with source map
	 * 2.Biz Logic:
	 * 3.Author : LGCNS
	 *</pre>
	 * @param source source map for merge
	 * @param target target map for result
	 * @return map
	 * @throws Exception
	 */
	public static Map<String, Object> merge(Map<String, Object> source, Map<String, Object> target) throws Exception {
		return merge(source, target, null);
	}
	
	/**
	 * 
	 *<pre>
	 * 1.Description: Merge target map with source map if key is matched with args
	 * 2.Biz Logic:
	 * 3.Author : LGCNS
	 *</pre>
	 * @param source source map for merge
	 * @param target target map for result
	 * @param args group of keys for merging 
	 * @return target map
	 * @throws Exception
	 */
	public static Map<String, Object> merge(Map<String, Object> source, Map<String, Object> target, String[] args) throws Exception {
		if (target == null) {
			target = new HashMap<String, Object>();
		}
		
		Set<Entry<String, Object>> mapSet = source.entrySet();
		Iterator<Entry<String, Object>> mapItr = mapSet.iterator();
		String key = null;
		while(mapItr.hasNext()) {
			key = mapItr.next().getKey();
			if (args != null) {
				for (String arg : args) {
					if (arg.equals(key)) {
						target.put(key, source.get(key));						
					}
				}
			}
			else {
				target.put(key, source.get(key));				
			}
		}
		return target;
	}
	
	/**
	 * 
	 * <pre>
	 * Read Request JSON Data
	 * </pre>
	 * @param request HttpServletRequest
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> readRequestData(HttpServletRequest request) throws Exception {
		/** Get Inputstream from HttpServletRequest **/
		InputStream is = request.getInputStream();

		/** Read data from InputStream **/
		byte[] requestData = IOUtils.toByteArray(is);
		
		String strParam = requestData != null ? new String(requestData) : null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Request Payload Data :: {}", strParam);
		}
		return (Map<String, Object>) (strParam != null ? JsonUtil.json2Map(strParam) : new HashMap<String, Object>());

	}
	
	
	public static CamelMap map2Camel(Map<String, Object> map) throws Exception {
		if (map == null) {
			return new CamelMap();
		}
		
		CamelMap camelMap = new CamelMap();
		Iterator<String> itrMap = map.keySet().iterator();
		while(itrMap.hasNext()) {
			String key = itrMap.next();
			camelMap.put(key, map.get(key));
		}
		return camelMap;
	}
	
	/**
	 * Change map to byte array
	 * @param headerData
	 * @param bodyData
	 * @param headerInfo
	 * @param dataInfo
	 * @return
	 * @throws Exception
	 */
	public static byte[] map2Byte(Map<String, Object> headerData, Map<String, Object> bodyData, List<CamelMap> headerInfo, List<CamelMap> dataInfo) throws Exception {
		StringBuilder sb = new StringBuilder();
		int totalLength = 0;
		/** Get Header **/
		
		for (CamelMap map : headerInfo) {
			String key = map.get("fieldName") != null ? String.valueOf(map.get("fieldName")) : ""; 
			int len = map.get("fieldLength") != null ? Integer.parseInt(String.valueOf(map.get("fieldLength"))) : 0;
			if (len == 0) {
				throw new BizException(String.format("The length of {} is 0", key));
			}
			totalLength += len;
			String value = headerData.get(key) != null ? String.valueOf(headerData.get(key)) : "";
			sb.append(StringUtil.padding(value, len, " "));
		}

		/** Body **/
		for (CamelMap map : dataInfo) {
			String key = map.get("fieldName") != null ? String.valueOf(map.get("fieldName")) : ""; 
			int len = map.get("fieldLength") != null ? Integer.parseInt(String.valueOf(map.get("fieldLength"))) : 0;
			if (len == 0) {
				throw new BizException(String.format("The length of {} is 0", key));
			}
			totalLength += len;
			String value = bodyData.get(key) != null ? String.valueOf(bodyData.get(key)) : "";
			sb.append(StringUtil.padding(value, len, " "));
		}
		byte[] result = sb.toString().getBytes();
		System.out.printf("totalLength :: %d, resutlLength :: %d", totalLength, result.length);
		return sb.toString().getBytes();
	}
	
}
