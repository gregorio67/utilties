package dymn.simulator.util;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

/**
 * -- Generate key pair
 * 1. openssl genrsa -aes256 -out dymn.key 2048
 * -- Convert private key to PKCS#8 format
 * 2. openssl pkcs8 -topk8 -in dymn.key -inform PEM -out dymn.pcks8.key -outform DER -nocrypt
 * -- Generate public key from key pair with DER format
 * 3. openssl rsa -in dymn.key -outform DER -pubout -out dymn.pub.key
 * -- Generate CSR(Certificate Signing Request) from key file 
 * 4. openssl req -new -key dymn.key -new -out dymn.csr
 * -- Generate certificat with DER format
 * 5. openssl req -key dymn.key -new -x509 -days 265 -out dymn.crt -outform DER
 * 
 */
public class CertiUtil {
	public static byte[] readBytes(String fileName) throws Exception {
		Path path = Paths.get(fileName);
		return Files.readAllBytes(path);
	}
	public static PublicKey publicKeyfromCertificate(String fileName) throws Exception {
		/** Change PEM-encoded certificate(.crt) to DER-encoded certificate(.der) 
	    command : openssl x509 -in dymn.crt -outform der -out dymn.der**/

		CertificateFactory cf = CertificateFactory.getInstance("x.509");
		Certificate cert = cf.generateCertificate(new FileInputStream(new File(fileName)));
		PublicKey publicKey = cert.getPublicKey();
		return publicKey;
	}
	public static PublicKey readPublicKey(String fileName) throws Exception {
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(readBytes(fileName));
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePublic(keySpec);
	}
	public static PrivateKey readPrivateKey(String fileName) throws Exception {
		/**
		 * openssl genrsa -aes256 -out server.key 2018
		 * openssl pkcs8 -topk8 -inform PEM -outform DER -in server.key -nocrypt > server.pkcs8.key
		 */
		PKCS8EncodedKeySpec  keySpec = new PKCS8EncodedKeySpec(readBytes(fileName));
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePrivate(keySpec);
	}
	public static byte[] encrypt(PublicKey key, byte[] plainText) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.doFinal(plainText);
	}

	public static byte[] encrypt(PrivateKey key, byte[] plainText) throws Exception {
//		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.doFinal(plainText);
	}
	
	public static byte[] decrypt(PrivateKey key, byte[] cipherText) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		cipher.init(Cipher.DECRYPT_MODE, key);
		return cipher.doFinal(cipherText);
	}
	
	public static byte[] decrypt(PublicKey key, byte[] cipherText) throws Exception {
//		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, key);
		return cipher.doFinal(cipherText);
	}
	
	public static void main(String args[]) throws Exception {
	
		
		/** Change PEM-encoded certificate(.crt) to DER-encoded certificate(.der) 
		    command : openssl x509 -in dymn.crt -outform der -out dymn.der**/
		

//		KeyFactory kf = KeyFactory.getInstance("RSA");
//		KeySpec keySpec = new PKCS8EncodedKeySpec(readBytes("D:/temp/openssl/dymn.key"));
//		PrivateKey key = kf.generatePrivate(keySpec);

		/**
		 * openssl genrsa -aes256 -out server.key 2018
		 * openssl pkcs8 -topk8 -inform PEM -outform DER -in server.key -nocrypt > server.pkcs8.key
		 */		
		PublicKey publicKey = publicKeyfromCertificate("D:/temp/key/dymn.crt");
//		PublicKey publicKey = readPublicKey("D:/temp/key/dymn.pub.key");
		PrivateKey privateKey = readPrivateKey("D:/temp/key/dymn.pcks8.key");

//		PublicKey publicKey = readPublicKey("D:/temp/openssl/dymn.csr");

		
		byte[] message = "This is test for certification crypto".getBytes();
		byte[] cipherText = encrypt(publicKey, message);
		byte[] plainText = decrypt(privateKey, cipherText);
		
		System.out.println(new String(plainText));
		
		
		byte[] cipherText1 = encrypt(privateKey, message);
		byte[] plainText1 = decrypt(publicKey, cipherText1);
		System.out.println(new String(plainText1));

	}	

}
