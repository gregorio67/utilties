package dymn.simulator.util;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileNioUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FileNioUtil.class);
	private static ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock(true);
	private static final int BLOCK_SIZE = 100;
	private static AtomicInteger lastBlock = new AtomicInteger();
	

	public static byte[] getBlockData(String fileName, int block) throws Exception {
//		if (block > lastBlock.get()) {
//			return null;
//		}
		
		byte[] rBytes = new byte[BLOCK_SIZE];
		if(!rwLock.isWriteLocked()) {
			
			Path path = Paths.get(fileName);
			AsynchronousFileChannel fChannel = AsynchronousFileChannel.open(path, StandardOpenOption.READ);
			ByteBuffer bytebuffer = ByteBuffer.allocateDirect(BLOCK_SIZE);
			long position = block * BLOCK_SIZE;
			Future<Integer> future = fChannel.read(bytebuffer, position);
			
			while(!future.isDone());
			
			int readLength = future.get();
			System.out.printf("%d bytes read", readLength);
			
			/** flip method is used before byte buffer read **/
			bytebuffer.flip();
			int idx = 0;
			while(bytebuffer.hasRemaining()) {
				rBytes[idx++] = (byte)bytebuffer.get();
			}
//			bytebuffer.get(rBytes, 0, rBytes.length);			
//			System.out.printf("%s read", new String(rBytes));
			bytebuffer.clear();
			fChannel.close();
		}
		
		return rBytes;
		
	}

	public static void writeData(String fileName, String data) throws Exception {
		
		RandomAccessFile raf = null;;
		FileChannel fChannel = null;
		
		try {
			raf = new RandomAccessFile(new File(fileName), "rw");
			fChannel = raf.getChannel();
			long position = fChannel.size();
			ByteBuffer bytebuffer = ByteBuffer.allocateDirect(BLOCK_SIZE);
			bytebuffer.clear();
			
			bytebuffer.put(fillData(data, BLOCK_SIZE));
			/** After put data to byte buffer, must be flip to change byte buffer position **/
			bytebuffer.flip();
			
			fChannel.write(bytebuffer, position);	
		}
		catch(Exception ex) {
			
		}
		finally {
			fChannel.close();
			raf.close();			
		}
	}
	
	
	public static byte[] fillData(String data, int size) throws Exception {
		
		byte[] retByte = new byte[size];
		int idx = 0;
		for (byte b : data.getBytes()) {
			retByte[idx++] = b;
		}
		
		return retByte;
	}
	
	public static void writeData(String fileName, String data, int position) throws Exception {
		appendData(fileName, data.getBytes());
	}
	
	
	public static void appendData(String fileName, String data) throws Exception {
		appendData(fileName, data.getBytes());
	}
	
	public static void appendData(String fileName, byte[] data) throws Exception {

		/** Set write lock **/
		rwLock.writeLock().lock();
		Path path = Paths.get(fileName);
	
		long position = 0L;
		Future<Integer> future = null;
		AsynchronousFileChannel fChannel = null;
		
		try {
			if (Files.notExists(path)) {
				fChannel = AsynchronousFileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
			}
			else {
				fChannel = AsynchronousFileChannel.open(path, StandardOpenOption.WRITE);			
			}

			position = fChannel.size();
			byte[] wByte = new byte[BLOCK_SIZE];
			for (int i = 0; i < data.length; i++) {
				wByte[i] = data[i];
			}
			ByteBuffer bytebuffer = ByteBuffer.wrap(wByte);
			future = fChannel.write(bytebuffer, position);
			bytebuffer.clear();
			System.out.printf("%s was written in %d position\n", future.get(), position);
			System.out.printf("Current Block :: %d\n", lastBlock.incrementAndGet());
		}
		catch(Exception ex) {
			ex.printStackTrace();	
		}
		finally {
			fChannel.close();
			rwLock.writeLock().unlock();
		}
	}
	
	
	public static String getDirectory(String fileName) throws Exception {
		int idx = fileName.lastIndexOf(File.separator);
		if (idx == -1) {
			idx = fileName.lastIndexOf("/");
		}
		return fileName.substring(0, idx);
	}
	
	public static String getFile(String fileName) throws Exception {
		int idx = fileName.lastIndexOf(File.separator);
		if (idx == -1) {
			idx = fileName.lastIndexOf("/");
		}
		return fileName.substring(idx+1);
	}
	
	
	public static void mkdir(String fileName) throws Exception {
		Path path = Paths.get(getDirectory(fileName));
		if (Files.notExists(path)) {
			Files.createDirectory(path);
//			Set<PosixFilePermission> permission = new HashSet<>();
//			permission.add(PosixFilePermission.OWNER_WRITE);
//			permission.add(PosixFilePermission.OWNER_READ);
//			Files.setPosixFilePermissions(path, permission);
		}
	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		String fileName = "d:/temp/file/random.txt";
		String data = "김도연 Random Access File Test";
		
		
//		System.out.printf(new String(getBlockData(fileName, 2)));

		writeData(fileName, data);
		
//		
		int idx = 0;
//		ExecutorService executor = Executors.newFixedThreadPool(3);
//		for (int i = 0;  i < 3; i++) {
//			executor.submit(new Runnable() {
//
//				@Override
//				public void run() {
//					String w = idx + ":" + data;
//					try {
//						appendData(fileName, w);
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}
//				
//			});			
//		}
//		executor.shutdown();
	}
}
