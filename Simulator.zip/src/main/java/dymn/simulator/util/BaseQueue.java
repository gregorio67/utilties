package dymn.simulator.util;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BaseQueue<T> {

	private static int DEFAULT_WAIT_TIME = 1000;
	private BlockingQueue<T> queue;
	private int maxSize;
	
	public BaseQueue(BlockingQueue<T> queue) {
		this.queue = queue;
	}

	public BaseQueue(BlockingQueue<T> queue, int maxSize) {
		this.queue = queue;
		this.maxSize = maxSize;
	}
	
	
	public <E> boolean put(T data) throws Exception {
		System.out.println("max Size :: " + maxSize + " queue Size ::" + queue.size());								
		return queue.offer(data, 1000, TimeUnit.MILLISECONDS);
	}
	
	public T get() throws Exception {
		return queue.poll(DEFAULT_WAIT_TIME, TimeUnit.MILLISECONDS);
	}
	
	public void queueState() throws Exception {
	}
	
	public static void main(String[] args) throws Exception {

		LinkedBlockingQueue<Map<String, Object>> blockQueue  = new LinkedBlockingQueue<>(10);
		ReentrantLock lock = new ReentrantLock();
		BaseQueue<Map<String, Object>> queue = new BaseQueue<>(blockQueue, 10);
		AtomicInteger cnt = new AtomicInteger(0);
		
		Runnable consumer = new Runnable() {

			@Override
			public void run() {
				while(true) {
					try {
						Map<String, Object> map = queue.get();
						System.out.println("consumer :: " + map);
						Thread.sleep(1000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}					
			}
		};
		
		Thread cThread = new Thread(consumer);
		cThread.start();
		
		Runnable producer1 = new Runnable() {

			@Override
			public void run() {
				while(true) {
					Map<String, Object> map = new HashMap<>();
					map.put("seq", cnt.getAndIncrement());
					
					try {
						if (queue.put(map)) {
							System.out.println("producer1 :: " + map);
						}
						else {
							System.out.println("producer1 fail to add");
						}
						Thread.sleep(1000);
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}
			}
		};
		Thread pThread1 = new Thread(producer1);
		pThread1.start();
		
		Runnable producer2 = new Runnable() {

			@Override
			public void run() {
				while(true) {
					Map<String, Object> map = new HashMap<>();
					map.put("seq", cnt.getAndIncrement());
					
					try {
						if (queue.put(map)) {
							System.out.println("producer2 :: " + map);
						}
						else {
							System.out.println("producer2 fail to add");
						}
						Thread.sleep(1000);
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}
			}
		};

		Thread pThread2 = new Thread(producer2);
		pThread2.start();
	}
}
