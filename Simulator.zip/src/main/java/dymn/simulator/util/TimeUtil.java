package dymn.simulator.util;

public class TimeUtil {

	/**
	 * Check time elapsed
	 * @param startTime
	 * @param executeTime
	 * @return
	 * @throws Exception
	 */
	public static boolean isOnElapsed(long startTime, int executeTime) throws Exception {
		if (executeTime == 0) {
			return false;
		}
		
		long currentTime = System.currentTimeMillis();

		if ((startTime + executeTime) >= currentTime) {
			return false;
		}
		else {
			return true;
		}
	}
	
	/**
	 * Convert seconds to mill seconds
	 * @param seconds
	 * @return
	 */
	public static long calcMills(int seconds) {
		return seconds * 1000;
	}
}
