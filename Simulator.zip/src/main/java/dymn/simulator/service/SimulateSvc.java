package dymn.simulator.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import dymn.simulator.base.BaseService;
import dymn.simulator.exception.BizException;
import dymn.simulator.http.HttpClientSvc;
import dymn.simulator.tcp.TcpClientSvc;
import dymn.simulator.util.TimeUtil;


@Service("simulateSvc")
public class SimulateSvc extends BaseService {

	@Resource(name = "tcpClientSvc")
	private TcpClientSvc tcpClientSvc;
	
	@Resource(name="httpClientSvc")
	private HttpClientSvc httpClientSvc;

	
	/**
	 * Simulate TCP Single
	 * @param host
	 * @param port
	 * @param serviceName
	 * @param runThread
	 * @param requestPacket
	 * @return
	 * @throws Exception
	 */
	public byte[] executeTcpSingleSimulate(String host, int port, final byte[] requestPacket) throws Exception {
		
		byte[] result = tcpClientSvc.sendMessage(host, port, requestPacket, true);

		return result;
	}
	
	
	/**
	 * Simulate Multiple TCP
	 * @param host
	 * @param port
	 * @param serviceName
	 * @param runThread
	 * @param requestPacket
	 * @return
	 * @throws Exception
	 */
	public byte[] executeTcpMultiSimulate(final String host, final int port, int runThread, int executeTime, final byte[] requestPacket) throws Exception {
		
		
		if (runThread == 1 && executeTime == 0) {
			return executeTcpSingleSimulate(host, port, requestPacket);
		}

		int totalSuccessCnt = 0;
		int totlaFailedCnt  = 0;		
		long startTime = System.currentTimeMillis();

		while(true) {
			int successCnt = 0;
			int failedCnt  = 0;

			ExecutorService executor = Executors.newFixedThreadPool(runThread);
			List<Future<byte[]>> futureList = new ArrayList<Future<byte[]>>();
			for (int i = 0; i < runThread; i++) {
					
				Future<byte[]> future = executor.submit(new Callable<byte[]>() {
					public byte[] call() throws Exception {
						byte[] result = null;
						try {
							result = tcpClientSvc.sendMessage(host, port, requestPacket, true);
							LOGGER.info("The result of {}:{} :: {}", host, port, new String(result));
						}
						catch(Exception ex) {
							LOGGER.error("Exception :: {}", ex.getMessage());
							return null;
						}
						return result;
					}
				});
				
				futureList.add(future);
			}
			
			/** Fetch Result **/
			for (Future<byte[]> future : futureList) {
				if (future.get() == null) {
					failedCnt++;
				}
				else {
					successCnt++;
				}
			}
			
			executor.shutdown();

			totalSuccessCnt += successCnt;
			totlaFailedCnt += failedCnt;
			
			if (TimeUtil.isOnElapsed(startTime, executeTime)) {
				break;
			}
		}
		
		/** Result **/
		StringBuilder sb = new StringBuilder();
		sb.append("Success Count ::[").append(totalSuccessCnt).append("] Failed Count :: [").append(totlaFailedCnt).append("]");
		return sb.toString().getBytes();
	}

	
	/**
	 * Execute HTTP single simulate
	 * @param url
	 * @param serviceName
	 * @param runThread
	 * @param param
	 * @param responseType
	 * @return  
	 * @throws Exception
	 */
	public <T> T executeHttpSingleSimulate(final String url, final Map<String, Object> param, final String contentType, String method) throws Exception {
    	T result = null;

		try {
			result = executeHttp(url, param, method, contentType);

			LOGGER.info("The result of {} :: {}", url, result);
		}
		catch(Exception ex) {
			LOGGER.error("Exception :: {}", ex.getMessage());
			throw new BizException(ex.getMessage());
		}
		
		return result;
	}	
	
	/**
	 * Execute HTTP post simulate
	 * @param url
	 * @param serviceName
	 * @param runThread
	 * @param param
	 * @param responseType
	 * @return  
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T executeHttpMultiSimulate(final String url, int runThread, int executeTime, final Map<String, Object> param, final String contentType, String method) throws Exception {

    	/** Execute Single **/
    	if (runThread == 1 && executeTime == 0) {
    		return executeHttpSingleSimulate(url, param, contentType, method);
    	}
    	
    	long startTime = System.currentTimeMillis();
    	int totalSuccessCnt = 0;
    	int totalFailedCnt = 0;

		/** Run Thread is more than one **/
		ExecutorService executor = Executors.newFixedThreadPool(runThread);

		List<Future<T>> futureList = new ArrayList<Future<T>>();
		for (int i = 0; i < runThread; i++) {

			Future<T> future = executor.submit(new Callable<T>() {
				public T call() throws Exception {
					Map<String, Integer> result = new HashMap<>();
					int failCount = 0;
					int successCount = 0;
					while (true) {
						try {
							result = executeHttp(url, param, method, contentType);
							if (result == null) {
								failCount++;
							}
							else {
								successCount++;
							}
							LOGGER.info("The result of {} :: {}", url, result);
						} catch (Exception ex) {
							LOGGER.error("Exception :: {}", ex.getMessage());
						}
						
						if (TimeUtil.isOnElapsed(startTime, executeTime)) {
							result.put("failCount", failCount);
							result.put("successCount", successCount);
							return (T) result;
						}
					}
				}
			});

			futureList.add(future);
		}    		
    	
		/** Fetch Result **/
    	for (Future<T> future : futureList) {
    		Map<String, Integer> threadResult = (Map<String, Integer>) future.get();
    		totalSuccessCnt += threadResult.get("failCount");
    		totalFailedCnt += threadResult.get("successCount");
    	}
    		   		
		executor.shutdown();

		StringBuilder sb = new StringBuilder();
		sb.append("Success Count ::[").append(totalSuccessCnt).append("] Failed Count :: [").append(totalFailedCnt).append("]");
		

		return (T)sb.toString();
	}
	
	/**
	 * Execute http call
	 * @param url
	 * @param param
	 * @param method
	 * @param contentType
	 * @param responseType
	 * @return
	 * @throws Exception
	 */
	private <T> T executeHttp(String url, Map<String, Object>param, String method, String contentType) throws Exception {
		T result = null;
		
		if ("POST".equalsIgnoreCase(method)) {
			if (contentType != null) {
				result = httpClientSvc.callPost(url, param, contentType);
			}
			else {
				result = httpClientSvc.callPost(url, param);								
			}											
		}
		else if ("GET".equalsIgnoreCase(method)){
			result = httpClientSvc.callGet(url);
			return result;
		}
		else {
			LOGGER.error("HTTP request method[{}] doesn't applicable", method);
			throw new BizException(String.format("HTTP request method[%s] doesn't applicable", method));
		}

		return result;
	}

}
