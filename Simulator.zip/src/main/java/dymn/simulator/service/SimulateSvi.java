package dymn.simulator.service;

public interface SimulateSvi {
	
	public byte[] executeSimulate(final String host, final int port, final String serviceName, int runThread, final byte[] requestPacket) throws Exception;

}
