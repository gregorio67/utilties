package dymn.simulator.service;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.stereotype.Service;

import io.netty.channel.ChannelHandlerContext;

@Service("tcpSvc2")
public class TcpSvc2 implements TcpSvi{
	private Lock lock = new ReentrantLock();
	
	@Override
	public void execService(Map<String, Object> map) {
		try {
			if (lock.tryLock(1000, TimeUnit.MILLISECONDS)) {
				byte[] message = (byte[]) map.get("message");
				ChannelHandlerContext context = (ChannelHandlerContext) map.get("context");
				
				String sendMsg = this.getClass().getName() + ":" + new String(message);
				context.writeAndFlush(sendMsg.getBytes());
				Thread.sleep(500);
			}
		}
		catch(InterruptedException ie) {
			ie.printStackTrace();
		}
		finally {
			lock.unlock();
		}
	}

}
