package dymn.simulator.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import dymn.simulator.base.BaseService;
import dymn.simulator.base.CamelMap;

@Service("serviceInfoSvc")
public class ServiceInfoSvc extends BaseService{

	@Resource(name="infLayoutSvc")
	private InfLayoutSvc infLayoutSvc;

	/**
	 * Select All service cnt
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public int selectAllServiceCnt(Map<String, Object> param) throws Exception {
		return baseDao.select("batch.web.inf.service.selAllServiceCnt", param);
	}

	/** 
	 * Select all service
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public List<CamelMap> selectAllService(Map<String, Object> param) throws Exception {
		return baseDao.selectList("batch.web.inf.service.selAllService", param);
	}

	/**
	 * Select Header and Message Id
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> selectHeadeAndMsgId(Map<String, Object> param) throws Exception {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		CamelMap infId = baseDao.select("batch.web.inf.service.selFieldName", param);
		
		String headId = infId.get("headInfId") != null ? String.valueOf(infId.get("headInfId")) : null;
		String msgId = infId.get("msgInfId") != null ? String.valueOf(infId.get("msgInfId")) : null;
		
		/** Search Field Name **/
		List<CamelMap> headList = null;
		List<CamelMap> msgList = null;
		if (headId != null || "".equals(headId)) {
			Map<String, Object> hMap = new HashMap<String, Object>();
			hMap.put("infId", headId);
			hMap.put("msgType", "I");
			headList = infLayoutSvc.selectField(hMap);
			resultMap.put("head", headList);
		}
		
		if (msgId != null) {
			Map<String, Object> hMap = new HashMap<String, Object>();
			hMap.put("infId", msgId);
			hMap.put("msgType", "I");
			msgList = infLayoutSvc.selectField(hMap);
			resultMap.put("msg", msgList);
		}
		
		return resultMap;
	}
	
}
