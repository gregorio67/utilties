package dymn.simulator.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import dymn.simulator.base.BaseService;
import dymn.simulator.base.CamelMap;

@Service("infLayoutSvc")
public class InfLayoutSvc extends BaseService {


	/**
	 * Select field
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public List<CamelMap> selectField(Map<String, Object> param) throws Exception {
		return baseDao.selectList("batch.web.inf.infLayout.selNameAndLength", param);
	}
	
}
