package dymn.simulator.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import dymn.simulator.base.BaseService;
import dymn.simulator.base.CamelMap;

@Service("hostInfoSvc")
public class HostInfoSvc extends BaseService{

	/** 
	 * Select Host Information with hostId or hostName
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public CamelMap selectHostInfo(Map<String, Object> param) throws Exception {
		
		/** Get Host Id from service Id **/
		CamelMap hostInfo = baseDao.select("batch.web.inf.service.selHostId", param);
		
		return baseDao.select("simulate.host.info.selHostInfo", hostInfo);
	}
}
