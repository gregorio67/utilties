package dymn.simulator.service;

import java.util.Map;

public interface TcpSvi {
	
	public void execService(Map<String, Object> map);

}
