/**
 * @Project :  스마트톨링정보시스템 구축
 * @Class : AgentAService.java
 * @Description : 
 *
 * @Author : LGCNS
 * @Since : 2017. 4. 20.
 *
 * @Copyright (c) 2018 EX All rights reserved.
 *-------------------------------------------------------------
 *              Modification Information
 *-------------------------------------------------------------
 * 날짜            수정자             변경사유 
 *-------------------------------------------------------------
 * 2018. 7. 6.        LGCNS             최초작성
 *-------------------------------------------------------------
 */

package dymn.simulator.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;

public abstract class AgentAService<T, V> {
	
	protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	public void process(T param, ChannelHandlerContext ctx, String isResponse) throws Exception {
		LOGGER.info("Input Parameter :: {}", param);
		
		V result = executeService(param);
		
		LOGGER.info("Result :: {}", result);
		if ("Y".equalsIgnoreCase(isResponse)) {
			ChannelFuture future = ctx.channel().writeAndFlush( result );			
			future.addListener(ChannelFutureListener.CLOSE);
		}
		
	}

	public abstract V executeService(T param) throws Exception; 
}
