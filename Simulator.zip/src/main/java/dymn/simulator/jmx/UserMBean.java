package dymn.simulator.jmx;

public interface UserMBean {
	
	public void printInfo();

}
