package dymn.simulator.jmx;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.springframework.stereotype.Component;

@Component
public class RegisterBean {

	public void registerBean() throws Exception {
		MBeanServer server = ManagementFactory.getPlatformMBeanServer();
		
		ObjectName name = new ObjectName("user:type=User");
		
		User userMBean = new User();
		userMBean.setUserName("gregorio");
		server.registerMBean(userMBean, name);
	}
}
