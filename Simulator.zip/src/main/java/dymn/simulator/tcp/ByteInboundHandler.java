/**
 * @Project :  스마트톨링정보시스템 구축
 * @Class : ByteServerHandler.java
 * @Description : 
 *
 * @Author : LGCNS
 * @Since : 2017. 4. 20.
 *
 * @Copyright (c) 2018 EX All rights reserved.
 *-------------------------------------------------------------
 *              Modification Information
 *-------------------------------------------------------------
 * 날짜            수정자             변경사유 
 *-------------------------------------------------------------
 * 2018. 7. 6.        LGCNS             최초작성
 *-------------------------------------------------------------
 */

package dymn.simulator.tcp;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import dymn.simulator.service.AgentAService;
import dymn.simulator.util.BaseQueue;
import dymn.simulator.util.BeanUtil;
import dymn.simulator.util.JsonUtil;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;


@Component
@ChannelHandler.Sharable
public class ByteInboundHandler extends SimpleChannelInboundHandler<byte[]> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger( ByteInboundHandler.class );
	
	@Resource(name="baseQueue")
	private BaseQueue<Map<String, Object>> baseQueue;
	
	@Override
	protected void channelRead0( ChannelHandlerContext ctx, byte[] msg ) throws Exception {
		LOGGER.info( "[Server][MSG RCV] {}", new String( msg, StandardCharsets.UTF_8 ) );
		
		Map<String, Object> inputMap = new HashMap<>();
		inputMap.put("context", ctx);
		inputMap.put("message", msg);
		LOGGER.info("Add Queue ::: {}", inputMap);
		baseQueue.put(inputMap);
				
//		String channelId = ctx.channel().id().asLongText();
//		InetSocketAddress address = ((InetSocketAddress)ctx.channel().remoteAddress());
//		address.getAddress().getHostAddress();
//		address.getPort();
//		
//		Map<String, Object> params = JsonUtil.json2Map(new String(msg));
//		String reqService = params.get("service") != null ? String.valueOf(params.get("service")) : null;
//		String responseYn = params.get("responseYn") != null ? String.valueOf(params.get("responseYn")) : "Y";
//		
//		if (reqService == null) {
//			Map<String, Object> msgMap = new HashMap<String, Object>();
//			msgMap.put("status", "F");
//			msgMap.put("message", "Service is null");
//			
//			ChannelFuture future = ctx.channel().writeAndFlush(JsonUtil.map2Json(msgMap).getBytes());
//			future.addListener(ChannelFutureListener.CLOSE);
//			return;
//		}
//		/** Call Service **/
//		LOGGER.info("Called {} service ", reqService);
//		AgentAService<Map<String, Object>, byte[]> service = BeanUtil.getBean( reqService );
//
//		/** Call Service and service send response **/
//		LOGGER.info("{} is called", reqService);
//		service.process(params, ctx, responseYn);

	}

	@Override
	public void exceptionCaught( ChannelHandlerContext ctx, Throwable cause ) throws Exception {
		LOGGER.error( "[Server][ERROR] ", cause );
	}
}
