/*------------------------------------------------------------------------------
 * PROJ   : UPLUS 해외 송금 프로젝트
 * NAME   : SocketChannelInitializer.java
 * DESC   : TCP Socket 채널 초기화 클래스
 * Author : 윤순혁
 * VER    : 1.0
 * Copyright 2016 LG CNS All rights reserved
 *------------------------------------------------------------------------------
 *                  변         경         사         항                       
 *------------------------------------------------------------------------------
 *    DATE       AUTHOR                      DESCRIPTION                        
 * ----------    ------  --------------------------------------------------------- 
 * 2016. 12. 6.  윤순혁  최초 프로그램 작성                                     
 */

package dymn.simulator.tcp;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.netty.handler.codec.bytes.ByteArrayDecoder;
import io.netty.handler.codec.bytes.ByteArrayEncoder;
import io.netty.util.concurrent.DefaultEventExecutorGroup;
import io.netty.util.concurrent.EventExecutorGroup;

/**
 * <PRE>
 * TCP Socket 채널 초기화 클래스
 * </PRE>
 *
 * @author    윤순혁
 * @version   1.0
 * @see       ChannelInitializer
 */
@Component
public class SocketChannelInitializer extends ChannelInitializer<SocketChannel> {

	@Resource(name = "byteInboundHandler")
	private ChannelInboundHandlerAdapter inboundhandlerAdapter;

	
	private MessageToMessageDecoder<?> messageDecoder;
	
	@Value("${event.group.max.thread}")
	private int maxThread;

	
	public void setInboundhandlerAdapter(ChannelInboundHandlerAdapter inboundhandlerAdapter) {
		this.inboundhandlerAdapter = inboundhandlerAdapter;
	}

	
	public void setMessageDecoder(MessageToMessageDecoder<?> messageDecoder) {
		this.messageDecoder = messageDecoder;
	}



	public void setMaxThread(int maxThread) {
		this.maxThread = maxThread;
	}

	/**
	 * @param defaultServerHandler the defaultServerHandler to set
	 */

	/* (non-Javadoc)
	 * @see io.netty.channel.ChannelInitializer#initChannel(io.netty.channel.Channel)
	 */
	@Override
	protected void initChannel( SocketChannel socketChannel ) throws Exception {
		EventExecutorGroup group = new DefaultEventExecutorGroup(maxThread);
		ChannelPipeline pipeline = socketChannel.pipeline();

		// the encoder and decoder (byte array : not sharable)
		pipeline.addLast(group, "byteDecoder", new ByteArrayDecoder() );  //Inbound
		pipeline.addLast(group, "byteEncoder", new ByteArrayEncoder() ); //Outbound
		
		/** Message Decoder **/
		if (messageDecoder != null) {
			pipeline.addLast(group, "messageDecoder", messageDecoder); //Inbound
		}

		/** Call business logic **/
		pipeline.addLast(group,"inboundhandlerAdapter", inboundhandlerAdapter ); //Inbound and return
	}
}
