/**
 * @Project :  스마트톨링정보시스템 구축
 * @Class : TcpInterfaceServiceImpl.java
 * @Description : 
 *
 * @Author : LGCNS
 * @Since : 2017. 4. 20.
 *
 * @Copyright (c) 2018 EX All rights reserved.
 *-------------------------------------------------------------
 *              Modification Information
 *-------------------------------------------------------------
 * 날짜            수정자             변경사유 
 *-------------------------------------------------------------
 * 2018. 4. 27.        LGCNS             최초작성
 *-------------------------------------------------------------
 */

package dymn.simulator.tcp;

import java.nio.channels.ClosedChannelException;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import dymn.simulator.exception.BizException;
import dymn.simulator.util.JsonUtil;
import dymn.simulator.util.PropertiesUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;

@Service("tcpClientSvc")
public class TcpClientSvc {

	private static final Logger LOGGER = LoggerFactory.getLogger(TcpClientSvc.class);

	@Resource(name="retryTemplate")
	private RetryTemplate retryTemplate;
	
	
	@Resource(name="retryPolicy")
	private SimpleRetryPolicy retryPolicy;

	/**
	 * TCP client send message
	 * @param host
	 * @param port
	 * @param requestPacket
	 * @param rcvWait
	 * @return
	 * @throws Exception
	 */
	public byte[] sendMessage(final String host, final int port, byte[] requestPacket, boolean rcvWait) throws Exception {
		/** Check input parameter **/
		if (host == null || requestPacket == null) {
			throw new BizException(" Server Information or send message is null");
		}
		
		long startTime = System.currentTimeMillis();
		
		/** Socket Channel **/
		Channel channel = null;
		final CountDownLatch latch = new CountDownLatch(1);

		/** Byte Handler **/
		ByteClientHandler clientHandler = null;

		int maxRetryCnt = PropertiesUtil.getInt("max.retry.count");
		
		final int maxRetries = retryPolicy.getMaxAttempts();
		
		/** Netty Event Loop Group **/
		final EventLoopGroup group = new NioEventLoopGroup();
		try {

			/** Create Client Handler **/
			clientHandler = new ByteClientHandler(requestPacket, rcvWait, latch);

			/** Create Client Bootstrap **/
			final Bootstrap bootstrap = BaseBootstrap.byteBootstrap(group, clientHandler);

					
			int rcvTimeout = PropertiesUtil.getInt("tcp.receive.timeout");
			if (LOGGER.isDebugEnabled()) {
				LOGGER.info("Retry Count :: {}, Receive Timeout :: {}", maxRetryCnt, rcvTimeout);
			}
			
			RetryCallback<Channel, Exception> retryCallback = new RetryCallback<Channel, Exception>() {
				@Override
				public Channel doWithRetry(RetryContext context) throws Exception {
					LOGGER.info("Retry :: Try to connect to {}/{} {}/{} times", host, port, context.getRetryCount() + 1, maxRetries);
					return bootstrap.connect(host, port).sync().channel();
				}
			};
			
			channel = retryTemplate.execute(retryCallback);
			
			if (channel == null) {
				LOGGER.error("Can't create channel, please check target {}/{} server", host, port);
				throw new BizException("channel is null");
			}
//			channel = retryTemplate.execute(new RetryCallback<Channel, Exception>() {
//
//				@Override
//				public Channel doWithRetry(RetryContext retrycontext) throws Exception {
//					Channel channel = null;
//					retrycontext.getRetryCount();
//					try {
//						channel = bootstrap.connect(host, port).sync().channel();
//					} catch (InterruptedException e) {
//						LOGGER.error("Interrupted :: [Client][ERROR] {}:{}Connection error occured. retry again {}/{}", host, port, retrycontext.getRetryCount(), retrycontext.getAttribute("maxAttempts"));
//					} catch(Exception ex) {
//						LOGGER.error("Exception :: [Client][ERROR] {}:{}Connection error occured. retry again {}/{}", host, port, retrycontext.getRetryCount(), retrycontext.getAttribute("maxAttempts"));						
//					}
//					
//					return channel;
//				}
//				
//			});
//
//			/** If connect is failed, retry **/
//			for (int retryCnt = 0; retryCnt < maxRetryCnt; retryCnt++) {
//				try {
//					channel = bootstrap.connect(host, port).sync().channel();
//					break;
//				} catch (Exception connectionError) {
//					
//					if (retryCnt == maxRetryCnt) {
//						// if.tcp.client.maxretry
//						LOGGER.error("[Client][ERROR] {}:{} Connection error occured", host, port);
//						throw connectionError;
//					} else {
//						LOGGER.error("[Client][ERROR] {}:{}Connection error occured. retry again {}/{}", host, port, retryCnt, maxRetryCnt);
//					}
//				}
//			}
			
			/** If needed to get response, wait for response **/
			if (rcvWait) {
				if (!latch.await(rcvTimeout, TimeUnit.MILLISECONDS)) {
					channel.disconnect().sync();
					throw new TimeoutException("[Client][MSG RCV TIMEOUT] TCP 수신 대기 시간을 넘었습니다");
				}				
			}
			
			LOGGER.info("Service is successfully done :: {}, {}", host, port, System.currentTimeMillis() - startTime);

			return clientHandler != null ? clientHandler.getResponse() : null;			
			
		}
		catch(ClosedChannelException ce) {
			LOGGER.error("Can't create channel, please check target {}/{} server", host, port);
			throw new BizException(ce.getMessage());
			
		}
		catch (Exception ex) {
			throw new BizException(ex.getMessage());
		} 
		finally {
			if (channel != null) {
				try {
					channel.closeFuture().sync();
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("Socket Channel is closed");
					}
				} 
				catch (InterruptedException interruptedEx) {
					LOGGER.error("Interrupted: {}", interruptedEx.getMessage());
				}
			}
			group.shutdownGracefully();
		}
		
	}

	
	public Map<String, Object> sendMessage(String host, int port, Map<String, Object> requestPacket, boolean rcvWait) throws Exception {
		/** Convert map to JSON String **/
		String sendData = JsonUtil.map2Json(requestPacket);

		/** Send and receive message with JSON type **/
		String rcvData = sendMessage(host, port, sendData, rcvWait);

		/** Convert JSON String to map **/
		return JsonUtil.json2Map(rcvData);
	}
	
	public String sendMessage(String host, int port, String requestPacket, boolean rcvWait) throws Exception {
		
		return new String(sendMessage(host, port, requestPacket.getBytes(), rcvWait));
	}

}
