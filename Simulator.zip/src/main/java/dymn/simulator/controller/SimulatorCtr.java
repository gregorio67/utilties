package dymn.simulator.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dymn.simulator.base.CamelMap;
import dymn.simulator.service.HostInfoSvc;
import dymn.simulator.service.ServiceInfoSvc;
import dymn.simulator.service.SimulateSvc;
import dymn.simulator.util.JsonUtil;
import dymn.simulator.util.MapUtil;


@Controller
public class SimulatorCtr extends dymn.simulator.base.BaseController {
	

	@Resource(name = "simulateSvc")
	private SimulateSvc simulateSvc;
	
	@Resource(name="hostInfoSvc")
	private HostInfoSvc hostInfoSvc;

	@Resource(name="serviceInfoSvc")
	private ServiceInfoSvc serviceInfoSvc;
	
	@RequestMapping(value ="/simulate/mainpage.do",  method=RequestMethod.GET)
	public String showMainPage() throws Exception {
		return "simulate/searchSimulate";
	}
	
	
	/**
	 * Search all Service
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value ="/simulate/search/allServices",  method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> selectAllService(@RequestBody Map<String, Object> param) throws Exception {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		int totalRecords = serviceInfoSvc.selectAllServiceCnt(param);	
		int rowCnt = dymn.simulator.util.PropertiesUtil.getInt("screen.page.rowcount");
		int totalPage = totalRecords / rowCnt;
		if ((totalPage * rowCnt) < totalRecords ) {
			totalPage += 1;
		}
		int curPage = param.get("curPage") != null ? Integer.parseInt(String.valueOf(param.get("curPage"))) : 1;
		
		List<dymn.simulator.base.CamelMap> list = serviceInfoSvc.selectAllService(param);
		
		resultMap.put("rows", list);
		resultMap.put("totalRecords", totalRecords);
		resultMap.put("curPage", curPage);
		resultMap.put("totalPage", totalPage);
		return resultMap;
		
	}
	
	/**
	 * Search Header and Data Filed for Service
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="simulate/search/field", method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> selectField(@RequestBody Map<String, Object> param) throws Exception {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		if (param.get("serviceId") == null) {
			
		}
		int runThread = param.get("runThread") != null ? Integer.parseInt(String.valueOf(param.get("runThread"))) : 1;
		int executeTime = param.get("executeTime") != null ? Integer.parseInt(String.valueOf(param.get("executeTime"))) : 0;
		String protocol = param.get("protocol") != null ? String.valueOf(param.get("protocol")) : "HTTP";
		
		/** Search Header ID and Service ID **/
		resultMap =  serviceInfoSvc.selectHeadeAndMsgId(param);	
		
		resultMap.put("runThread", runThread);
		resultMap.put("executeTime", executeTime);
		resultMap.put("protocol", protocol);
		
		return resultMap;		
	}
	
	/**
	 * Popup window open
	 * @param viewname
	 * @param serviceId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="simulate/popuppage.do", method= {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView popupPage(@RequestParam String viewname, @RequestParam String serviceId) throws Exception {
		
		return new ModelAndView(viewname, "serviceId", serviceId);
	}	
	
	/**
	 * Execute Tcp simulate
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "simulate/execute/tcp", method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> runTcpSimulate(@RequestBody Map<String, Object> param) throws Exception {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();

		int runThread = param.get("runThread") != null ? Integer.parseInt(String.valueOf( param.get("runThread"))) : 1;
		int executeTime = param.get("executeTime") != null ? Integer.parseInt(String.valueOf( param.get("executeTime"))) : 0;
		
		Map<String, Object> headerData = (Map<String, Object>) param.get("head");
		Map<String, Object> bodyData = (Map<String, Object>) param.get("msg");
		
		
		/** Get Host Information **/
		CamelMap hostInfo = hostInfoSvc.selectHostInfo(param);
		
		/** TCP Communication **/
		Map<String, Object> layout =  serviceInfoSvc.selectHeadeAndMsgId(param);
			
		String ipAddr = hostInfo.get("ipAddr") != null ? String.valueOf(hostInfo.get("ipAddr")):null;
		int port =  hostInfo.get("port") != null ? Integer.parseInt(String.valueOf(hostInfo.get("port"))):0;		
			
		final byte[] requestPacket = MapUtil.map2Byte(headerData, bodyData, (List<CamelMap>)layout.get("head"), (List<CamelMap>)layout.get("msg"));

		byte[] result = null;
		if (runThread == 1 && executeTime == 0) {
			result = simulateSvc.executeTcpSingleSimulate(ipAddr, port, requestPacket);								
		}
		else {
			result = simulateSvc.executeTcpMultiSimulate(ipAddr, port, runThread, executeTime, requestPacket);				
		}
			
		resultMap.put("code", "S");
		resultMap.put("message", new String(result));			
		
		return resultMap;
	}

	
	/**
	 * Execute HTTP simulate
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "simulate/execute/http", method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> runHttpSimulate(@RequestBody Map<String, Object> param) throws Exception {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();

		int runThread = param.get("runThread") != null ? Integer.parseInt(String.valueOf( param.get("runThread"))) : 1;
		int executeTime = param.get("executeTime") != null ? Integer.parseInt(String.valueOf( param.get("executeTime"))) : 0;
		
		Map<String, Object> headerData = (Map<String, Object>) param.get("head");
		Map<String, Object> bodyData = (Map<String, Object>) param.get("msg");
		
		
		/** Get Host Information **/
		CamelMap hostInfo = hostInfoSvc.selectHostInfo(param);

		/** HTTP Communication **/
		String url = hostInfo.get("url") != null ? String.valueOf(hostInfo.get("url")) : null;
		String contentType =  hostInfo.get("contentType") != null ? String.valueOf(hostInfo.get("contentType")) : null;
		String method =  hostInfo.get("reqMethod") != null ? String.valueOf(hostInfo.get("reqMethod")) : null;
			
		Map<String, Object> httpMap = null;
			
		if (headerData.size() > 0 && bodyData.size() > 0) {
			httpMap = MapUtil.merge(headerData, bodyData);
		}
		else if (headerData.size() > 0) {
			httpMap = headerData;
		}
		else if (bodyData.size() > 0) {
			httpMap = bodyData;
		}

		try {
			/** Single Simulation**/
			if (runThread == 1 && executeTime == 0) {
				String response = simulateSvc.executeHttpSingleSimulate(url, httpMap, contentType, method);					
				resultMap.put("code", "S");
				resultMap.put("message", response);
			}
				/** Multiple Simulation **/
			else {
				String response = simulateSvc.executeHttpMultiSimulate(url, runThread, executeTime, httpMap, contentType, method);	
				resultMap.put("code", "S");
				resultMap.put("message", response);
			}
				
		}
		catch(Exception ex) {
			resultMap.put("code", "E");
			resultMap.put("message", ex.getMessage());
			return resultMap;
		}
		
		return resultMap;
	}	
}
