package dymn.simulator.filter;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dymn.simulator.exception.BizException;
import dymn.simulator.util.JsonUtil;
import dymn.simulator.util.SessionUtil;

public class CsrfRequestWrapper extends HttpServletRequestWrapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(CsrfRequestWrapper.class);
	/* Request Body Contents */
	private String requestBody = null;
	
	public CsrfRequestWrapper(HttpServletRequest request) throws Exception{
		super(request);
		init(request);
	}
	
	private void init(HttpServletRequest request) throws Exception {
		
		String requestURI = request.getRequestURI();
		String method = request.getMethod();
		
		String readBody = IOUtils.toString(request.getInputStream());
		
		/** Check CSRF Token **/
		if (!"/movepage.do".equalsIgnoreCase(requestURI) && !"/main/mainpage.do".equals(requestURI) && !"GET".equals(method)) {
			String csrfToken = SessionUtil.getSession("csrfToken") != null ? String.valueOf(SessionUtil.getSession("csrfToken")) : "";
			Map<String, String[]> reqMap = request.getParameterMap();
			String paramToken = reqMap.get("csrfToken") != null ? String.valueOf(reqMap.get("csrfToken")) : null;
			if (paramToken == null) {
				Map<String, Object> jsonMap = JsonUtil.json2Map(readBody);
				paramToken = jsonMap.get("csrfToken") != null ? String.valueOf(jsonMap.get("csrfToken")) : "";
			}
			if (!csrfToken.equals(paramToken)) {
				LOGGER.error("You can't use this system, token is not match :: {}:{}", csrfToken, paramToken);
				throw new BizException("You can't use this system, token is not match");			
			}			
		}
		
		requestBody = readBody;
	}
	
	
	@Override
	public ServletInputStream getInputStream() throws IOException {
		final ByteArrayInputStream bios = new ByteArrayInputStream(requestBody.getBytes());
		return new ServletInputStream() {
			public int read() throws IOException {
				return bios.read();
			}

			@Override
			public boolean isFinished() {
				return false;
			}

			@Override
			public boolean isReady() {
				return false;
			}

			@Override
			public void setReadListener(ReadListener listner) {				
			}
		};
	}
	
	@Override
	public BufferedReader getReader() throws IOException {
		return new BufferedReader(new InputStreamReader(this.getInputStream()));
	}	

}
