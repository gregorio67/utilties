package dymn.simulator.filter;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SessionCounter implements ServletContextListener, HttpSessionListener, ServletRequestListener {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SessionCounter.class);
	private static final String ATTR_NAME="session.counter";
	private Map<HttpSession, String> sessionMap = new ConcurrentHashMap<HttpSession, String>();
	private AtomicInteger sessionCount = new AtomicInteger();
	
	@Override
	public void contextInitialized(ServletContextEvent event) {
		event.getServletContext().setAttribute(ATTR_NAME, this);
		sessionCount.set(0);
	}

    public void contextDestroyed(ServletContextEvent servletcontextevent) {
    }

	@Override
	public void requestInitialized(ServletRequestEvent event) {
		HttpServletRequest request = (HttpServletRequest)event.getServletRequest();
		HttpSession session = request.getSession();
		if (session.isNew()) {
			sessionMap.put(session, request.getRemoteAddr());
		}
	}
	
    public void requestDestroyed(ServletRequestEvent servletrequestevent) {
    }	
	
    public void sessionCreated(HttpSessionEvent event) {
    	LOGGER.info("Currently total session count is {}", sessionCount.incrementAndGet());
    }

    public void sessionDestroyed(HttpSessionEvent event) {
    	LOGGER.info("Currently total session count is {}", sessionCount.decrementAndGet());
    }
	
    public static SessionCounter getInstance(ServletContext context) {
    	return (SessionCounter)context.getAttribute(ATTR_NAME);
    }
    
    public int getCount(String remoteAddr) {
    	return Collections.frequency(sessionMap.values(), remoteAddr);
    }
    
    public int getTotalSession() {
    	return sessionCount.get();
    }

}
