package dymn.simulator.crawler;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Connection;
import org.jsoup.Connection.Method;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsoupCrawler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JsoupCrawler.class);
	private static final int DEFAULT_TIMEOUT = 5000;
	
	
	/**
	 * Get document from URL
	 * @param url
	 * @param method
	 * @param headers
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public static Document getDocument(String url, Method method) throws Exception {
		return getDocument(url, method, null, null, null);
	}
	
	public static Document getDocument(String url, Method method, Map<String, String> param) throws Exception {
		return getDocument(url, method, null, param, null);
	}
	
	public static Document getDocument(String url, Method method, Map<String, String> headers, Map<String, String> param, Map<String, String> cookies) throws Exception {
		
		Document doc = null;
		
		Connection conn = getConnection(url, headers, param, cookies);
		if (method == Method.POST) {
			doc = conn.post();
		}
		else if (method == Method.GET) {
			doc = conn.get();
		}
		
		return doc;
	}
	
	/** 
	 * Parsing HTML Document
	 * @param fileName String file name
	 * @return
	 * @throws Exception
	 */
	public static Document parseDocument(String fileName) throws Exception {
		Document doc = Jsoup.parse(new File(fileName), "UTF-8");
		
		return doc;
	}

	/** 
	 * Retrieve elements from document
	 * @param doc
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public static Elements getElements(Document doc, String element) throws Exception {
		Elements elements = doc.select(element);
		return elements;
	}
	
	
	/**
	 * Get all links from document
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	public static List<Map<String, String>> getAllLinks(Document doc) throws Exception {
		Elements links = doc.select("a[href]");
		List<Map<String, String>> linkList = new ArrayList<Map<String, String>>();
		
		for (Element link : links) {
			Map<String, String> linkMap = new HashMap<String, String>();
			String text = link.text();
			String attr = link.attr("href");
			linkMap.put(text, attr);
			linkList.add(linkMap);
		}
		
		return linkList;
	}
	
	/**
	 * Jsoup connection
	 * @param url
	 * @param headers
	 * @param param
	 * @param cookies
	 * @return
	 * @throws Exception
	 */
	public static Connection getConnection(String url, Map<String, String> headers, Map<String, String> param, Map<String, String> cookies) throws Exception {
		Connection conn = null;
		conn = Jsoup.connect(url)
				.userAgent("Mozilla")
				.timeout(DEFAULT_TIMEOUT);
		
		if (headers != null ) {
			conn = 	conn.headers(headers);
		}
		
		if (param != null){
			conn = conn.data(param);	
		}
		
		if (cookies != null) {
			conn = conn.cookies(cookies);
		}
		
		return conn;
		
	}
}
