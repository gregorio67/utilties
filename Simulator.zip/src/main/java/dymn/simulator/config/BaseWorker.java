package dymn.simulator.config;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import dymn.simulator.exception.BizException;
import dymn.simulator.service.TcpSvc1;
import dymn.simulator.service.TcpSvc2;
import dymn.simulator.util.BaseQueue;

@Component
public class BaseWorker implements Runnable {

	@Resource(name = "baseQueue")
	private BaseQueue<Map<String, Object>> baseQueue;
	private AtomicInteger cnt = new AtomicInteger(0);
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseWorker.class);
	
	@Resource(name = "tcpSvc1")
	private TcpSvc1 tcpSvc1;

	@Resource(name = "tcpSvc2")
	private TcpSvc2 tcpSvc2;

	@Override
	public void run() {
		while(true) {
			try {
				Map<String, Object> map = baseQueue.get();
				
				if (map != null) {
					int c = cnt.getAndIncrement();
					if (c %2 == 0) {
						tcpSvc1.execService(map);
					}
					else {
						tcpSvc2.execService(map);						
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				throw new BizException(e);
			}	
		}
	}

}
