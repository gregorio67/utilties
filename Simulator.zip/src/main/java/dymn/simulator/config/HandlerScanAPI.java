package dymn.simulator.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
public class HandlerScanAPI {

	
	private ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
	private String basePackage = "dymn.simulator";
	private List<Map<String, Object>> apiList = new ArrayList<>();
	
	
	{
		scanner.addIncludeFilter(new AnnotationTypeFilter(RequestMapping.class));
	}
	
	@PostConstruct
	private void apiInit() {
		this.beans();
		
	}
	
	private void beans() {
		String beanClassName = null;
		Class<?> bean = null;
		
		for (BeanDefinition bd : scanner.findCandidateComponents(basePackage)) {
			beanClassName = bd.getBeanClassName();
			try {
				bean = Class.forName(beanClassName);
				methods(bean);
			}
			catch(ClassNotFoundException cnfe) {
				cnfe.printStackTrace();
			}
		}
	}
	
	private void methods(Class<?> bean) {
		String rootUrl = ((RequestMapping) bean.getAnnotation(RequestMapping.class)).value()[0];
	}
	
}
