package dymn.simulator.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import dymn.simulator.base.BaseConstants;
import dymn.simulator.http.BaseClosableHttpClient;
import dymn.simulator.util.PropertiesUtil;

@Configuration
public class FactoryBeanConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(FactoryBeanConfig.class);
	
	
	@Bean("closableHttpClient") 
	public BaseClosableHttpClient closableHttpClient() {
		BaseClosableHttpClient closableHttpClient = new BaseClosableHttpClient();
		
		boolean ssl = "TRUE".equalsIgnoreCase(PropertiesUtil.getString("http.client")) ? true: false;
		int connectTimeout = PropertiesUtil.getInt("http.client.connection.timeout");
		int readTimeout = PropertiesUtil.getInt("http.client.read.timeout");
		int maxPool = PropertiesUtil.getInt("http.client.max.pool");

		if (connectTimeout == 0) {
			connectTimeout = BaseConstants.DEFAULT_HTTP_CONNECT_TIMEOUT;
		}
		if (readTimeout == 0) {
			connectTimeout = BaseConstants.DEFAULT_HTTP_READ_TIMEOUT;
		}
		if (maxPool == 0) {
			maxPool = BaseConstants.DEFAULT_HTTP_MAX_POOL;
		}
		
		closableHttpClient.setSsl(ssl);
		closableHttpClient.setConnectTimeout(connectTimeout);
		closableHttpClient.setReadTimeout(readTimeout);
		closableHttpClient.setMaxPool(maxPool);
		LOGGER.info("Http client is created :: {}, {}, {}, {}", ssl, connectTimeout, readTimeout, maxPool);
		return closableHttpClient;
	}
}
