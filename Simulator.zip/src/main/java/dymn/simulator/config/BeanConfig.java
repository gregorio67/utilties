package dymn.simulator.config;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import dymn.simulator.util.BaseQueue;

@Configuration
public class BeanConfig {
	

	@Bean(name="baseQueue")
	public BaseQueue<Map<String, Object>> baseQueue() {
		
		LinkedBlockingQueue<Map<String, Object>> blockQueue = new LinkedBlockingQueue<>();
		return new BaseQueue<>(blockQueue);
	}
	
}
