package dymn.simulator.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import dymn.simulator.base.BaseConstants;
import dymn.simulator.util.PropertiesUtil;

@Configuration
public class RetryConfig {
	
	/**
	 * Create backoff policy
	 * @return
	 * @throws Exception
	 */
	@Bean("fixedBackOffPolicy")
	public FixedBackOffPolicy fixedBackOffPolicy() throws Exception {
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		int backoffPeriod = PropertiesUtil.getInt("retry.backoff.period");
		if (backoffPeriod == 0) {
			backoffPeriod = BaseConstants.DEFAULT_RETRY_PERIOD;
		}
		fixedBackOffPolicy.setBackOffPeriod(backoffPeriod);
		
		return fixedBackOffPolicy;
	}

	
	/**
	 * Create retry policy
	 * @return
	 * @throws Exception
	 */
	@Bean("retryPolicy")
	public SimpleRetryPolicy retryPolicy() throws Exception {
		Map<Class<? extends Throwable>, Boolean> map = new HashMap<Class<? extends Throwable>, Boolean>();
		
		String[] classes = PropertiesUtil.getString("retry.exception.classes") != null ? PropertiesUtil.getString("retry.exception.classes").split(",") : new String[] {""};
		if (classes.length == 0) {
			map.put(java.lang.Exception.class, true);
		}
		else {
			for (String clazzName : classes) {
				@SuppressWarnings("unchecked")
				Class<? extends Throwable> clazz = (Class<? extends Throwable>) Class.forName(clazzName);
				map.put(clazz, true);
			}
		}
		int retryCnt = PropertiesUtil.getInt("retry.max.count");
		if (retryCnt <= 0) {
			retryCnt = BaseConstants.DEFAULT_RETRY_COUNT;
		}
		SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(retryCnt, map);
		return retryPolicy;
	}

	/**
	 * Create retry template
	 * @return
	 * @throws Exception
	 */
	@Bean("retryTemplate")
	public RetryTemplate retryTemplate() throws Exception {
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy());
		retryTemplate.setRetryPolicy(retryPolicy());
		
		return retryTemplate;
	}
}

//
//<bean id="fixedBackOffPolicy" class="org.springframework.retry.backoff.FixedBackOffPolicy">
//<property name="backOffPeriod" value="2000" />
//</bean>
//
//<bean id="retryPolicy" class="org.springframework.retry.policy.SimpleRetryPolicy">
//<!-- constructor-arg index="0" value="3" />
//<constructor-arg index="1">
//	<map>
//    	<entry key="excepton" value="java.lang.Exception" />
//    	<entry key="closedChannelException" value="java.nio.channels.ClosedChannelException" />    		
//	</map>
//</constructor-arg-->
//<property name="maxAttempts" value="5" />
//</bean>
//
//
//<bean id="retryTemplate" class="org.springframework.retry.support.RetryTemplate">
//<property name="backOffPolicy" ref="fixedBackOffPolicy" />
//<property name="retryPolicy" ref="retryPolicy" />
//</bean>
//</beans>