package dymn.simulator.http;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.SSLException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

import dymn.simulator.exception.BizException;



public class SimpleHttpClient {

	@SuppressWarnings("unchecked")
	public static <T> T httpGet(String URL) throws Exception {
		CloseableHttpClient httpClient = HttpClients.custom().setRetryHandler(retryHandler()).build();
		CloseableHttpResponse httpResponse = null;
		HttpEntity responseEntity = null;
		T responseBody = null;

		HttpGet httpGet = new HttpGet(URL);

		/** Create response handler **/
		ResponseHandler<HttpEntity> responseHandler = new ResponseHandler<HttpEntity>() {
			@Override
			public HttpEntity handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
				if (status >= 200 && status < 300) {
					HttpEntity responseEntity = response.getEntity();
					return responseEntity;
				} else {
					throw new ClientProtocolException("Unexpected response status: " + status);
				}
			}
		};

		try {
			httpResponse = httpClient.execute(httpGet);
			responseEntity = responseHandler.handleResponse(httpResponse);
			responseBody = (T) (responseEntity != null ? EntityUtils.toString(responseEntity) : null);
			;
		} catch (Exception ex) {
			throw new BizException(ex.getMessage());

		} finally {
			 if (httpClient != null) httpClient.close();
			 if (httpResponse != null) httpResponse.close();
		}
		return responseBody;

	}

	private static HttpRequestRetryHandler retryHandler() {
		return new HttpRequestRetryHandler() {

			@Override
			public boolean retryRequest(IOException exception, int execCount, HttpContext httpcontext) {
				if (execCount >= 5) {
					return false;
				}

				if (exception instanceof InterruptedIOException) {
					return false;
				}

				if (exception instanceof UnknownHostException) {
					return false;
				}
				if (exception instanceof SSLException) {
					return false;
				}

				HttpClientContext clientContext = HttpClientContext.adapt(httpcontext);
				HttpRequest request = clientContext.getRequest();
				boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);
				if (idempotent) {
					return true;
				}
				return false;
			}

		};
	}

	public static void main(String args[]) throws Exception {

		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				String result = null;
				try {
					result = httpGet("http://localhost:8080");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(result);				
			}
			
		};
		
		Timer timer = new Timer("httpGet");
		
		long delay = 1000L;
		long period = 5000L;
		
		timer.scheduleAtFixedRate(task, delay, period);
		
	}
}
