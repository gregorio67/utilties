/**
 * @Project :  스마트톨링정보시스템 구축
 * @Class : HttpService.java
 * @Description : 
 *
 * @Author : LGCNS
 * @Since : 2017. 4. 20.
 *
 * @Copyright (c) 2018 EX All rights reserved.
 *-------------------------------------------------------------
 *              Modification Information
 *-------------------------------------------------------------
 * 날짜            수정자             변경사유 
 *-------------------------------------------------------------
 * 2018. 6. 22.        LGCNS             최초작성
 *-------------------------------------------------------------
 */

package dymn.simulator.http;

import java.io.File;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.net.ssl.SSLException;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import dymn.simulator.base.BaseConstants;
import dymn.simulator.exception.BizException;
import dymn.simulator.util.JsonUtil;
import dymn.simulator.util.PropertiesUtil;

@Service("httpClientSvc")
public class HttpClientSvc {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientSvc.class);
	
	@Resource(name="closableHttpClient")
	private CloseableHttpClient httpClient;
	
	@Resource(name="retryTemplate")
	private RetryTemplate retryTemplate;
	
	public void setHttpClient(CloseableHttpClient httpClient) {
		this.httpClient = httpClient;
	}

	/**
	 * HTTP Post
	 * @param URL
	 * @param param
	 * @param responseType
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T callPost(String URL, Map<String, Object> param) throws Exception {
		
		List<NameValuePair> sendParam = new ArrayList<NameValuePair>();
		if (param != null) {
			Iterator<String> paramItr = param.keySet().iterator();
			while(paramItr.hasNext()) {
				String key = paramItr.next();
				sendParam.add(new BasicNameValuePair(key, String.valueOf(param.get(key))));
			}			
		}
		
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(sendParam, Consts.UTF_8);
		HttpPost httpPost = new HttpPost(URL);
		
		httpPost.setEntity(entity);
				
		/** Create response handler **/
		ResponseHandler<HttpEntity> responseHandler = new ResponseHandler<HttpEntity>() {

			@Override
			public HttpEntity handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity responseEntity = response.getEntity();
                    return responseEntity;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
			}
		};
		
		HttpEntity responseEntity = null;
		CloseableHttpResponse httpResponse = null;

		final int maxRetryCnt = PropertiesUtil.getInt("max.retry.count") > 0 ? PropertiesUtil.getInt("max.retry.count") : BaseConstants.DEFAULT_RETRY_COUNT;;
		
		/** Retry callback **/
		RetryCallback<CloseableHttpResponse, Exception> retryCallback = new RetryCallback<CloseableHttpResponse, Exception>() {
			@Override
			public CloseableHttpResponse doWithRetry(RetryContext context) throws Exception {
				LOGGER.info("Retry :: Try to connect to {} {}/{} times", URL, context.getRetryCount() + 1, maxRetryCnt);
				return httpClient.execute(httpPost);
			}
		};
				
		/** HTTP post execute **/
		httpResponse = retryTemplate.execute(retryCallback);		
		responseEntity = responseHandler.handleResponse(httpResponse);

		T responseBody = null;
		try {
			responseBody = (T) (responseEntity != null ? EntityUtils.toString(responseEntity) : null);;			
		}
		catch(Exception ex) {
			throw new BizException(ex.getMessage());
		}
		finally {
			if (httpResponse != null) httpResponse.close();
		}

		return responseBody;
	}

	
	/**
	 * HTTP Post
	 * @param URL
	 * @param param
	 * @param contentType
	 * @param responseType
	 * @return
	 * @throws Exception
	 */
	public <T> T callPost(String URL, Map<String, Object> param, String contentType) throws Exception {
		String jsonData = JsonUtil.map2Json(param);
		
		return callPost(URL, jsonData, contentType);
	}
	/**
	 * HTTP post
	 * @param URL
	 * @param param
	 * @param contentType
	 * @param responseType
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T callPost(String URL, String param, String contentType) throws Exception {

		HttpPost httpPost = new HttpPost(URL);
		httpPost.setHeader("Content-Type", contentType);
		StringEntity entity = null;
		if (param != null) {
			entity = new StringEntity(param);
		}
		if (entity != null) {
		    httpPost.setEntity(entity);			
		}
		
		/** Create response handler **/
		ResponseHandler<HttpEntity> responseHandler = new ResponseHandler<HttpEntity>() {
			@Override
			public HttpEntity handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity responseEntity = response.getEntity();
                    return responseEntity;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
			}
		};
		
		
		/** HTTP post execute **/
		HttpEntity responseEntity = null;
		CloseableHttpResponse httpResponse = null;

		final int maxRetryCnt = PropertiesUtil.getInt("max.retry.count") > 0 ? PropertiesUtil.getInt("max.retry.count") : BaseConstants.DEFAULT_RETRY_COUNT;;
		
		/** Retry callback **/
		RetryCallback<CloseableHttpResponse, Exception> retryCallback = new RetryCallback<CloseableHttpResponse, Exception>() {
			@Override
			public CloseableHttpResponse doWithRetry(RetryContext context) throws Exception {
				LOGGER.info("Retry :: Try to connect to {} {}/{} times", URL, context.getRetryCount() + 1, maxRetryCnt);
				return httpClient.execute(httpPost);
			}
		};
		
		httpResponse = retryTemplate.execute(retryCallback);		
		responseEntity = responseHandler.handleResponse(httpResponse);

		T responseBody = null;
		try {
			responseBody = (T) (responseEntity != null ? EntityUtils.toString(responseEntity) : null);;			
		}
		catch(Exception ex) {
			throw new BizException(ex.getMessage());
		}
		finally {
			if (httpResponse != null) httpResponse.close();
		}
		
		return responseBody;		
	}	

	/**
	 * HTTP post for multipart
	 * @param URL
	 * @param param
	 * @param filePath
	 * @param responseType
	 * @return
	 * @throws Exception
	 */
	public <T> T callMultiPartPost(String URL, Map<String, String> param, String filePath, final Class<?> responseType) throws Exception {
				
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		Iterator<String> paramItr = param.keySet().iterator();
		while(paramItr.hasNext()) {
			String key = paramItr.next();
			builder.addTextBody(key, param.get(key));
		}
		builder.addBinaryBody("file", new File(filePath), ContentType.APPLICATION_OCTET_STREAM, filePath);
		HttpPost httpPost = new HttpPost(URL);
		HttpEntity multipart = builder.build();
	    httpPost.setEntity(multipart);
		
		
		ResponseHandler<HttpEntity> responseHandler = new ResponseHandler<HttpEntity>() {
			@Override
			public HttpEntity handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity responseEntity = response.getEntity();
                    return responseEntity;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
			}
		};
		
		HttpEntity responseEntity = null;
		try {
			responseEntity = httpClient.execute(httpPost, responseHandler);
		}
		catch(Exception ex) {
			LOGGER.error("Http Post error :: {}", ex.getMessage());
			throw new BizException(ex.getMessage());
		}
		finally {
		}

		@SuppressWarnings("unchecked")
		T responseBody = (T) (responseEntity != null ? EntityUtils.toString(responseEntity) : null);;
		
		return responseBody;
	}
	
	@SuppressWarnings("unchecked")
	public <T> T callGet(String URL) throws Exception {
		
		HttpGet httpGet = new HttpGet(URL);
		
		CloseableHttpResponse httpResponse = null;
		HttpEntity responseEntity = null;
		
		final int maxRetryCnt = PropertiesUtil.getInt("max.retry.count") > 0 ? PropertiesUtil.getInt("max.retry.count") : BaseConstants.DEFAULT_RETRY_COUNT;;
		
		/** Create response handler **/
		ResponseHandler<HttpEntity> responseHandler = new ResponseHandler<HttpEntity>() {
			@Override
			public HttpEntity handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity responseEntity = response.getEntity();
                    return responseEntity;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
			}
		};
		
		/** Retry callback **/
		RetryCallback<CloseableHttpResponse, Exception> retryCallback = new RetryCallback<CloseableHttpResponse, Exception>() {
			@Override
			public CloseableHttpResponse doWithRetry(RetryContext context) throws Exception {
				LOGGER.info("Retry :: Try to connect to {} {}/{} times", URL, context.getRetryCount() + 1, maxRetryCnt);
				return httpClient.execute(httpGet);
			}
		};
		
		httpResponse = retryTemplate.execute(retryCallback);		
		responseEntity = responseHandler.handleResponse(httpResponse);

		T responseBody = null;
		try {
			responseBody = (T) (responseEntity != null ? EntityUtils.toString(responseEntity) : null);;			
		}
		catch(Exception ex) {
			throw new BizException(ex.getMessage());
		}
		finally {
			if (httpResponse != null) httpResponse.close();
		}
		
		return responseBody;
		
	}
}
