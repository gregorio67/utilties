package dymn.simulator.jni;

public class HelloJni {

	static {
		System.loadLibrary("hello");
		System.out.println("hello library is loaded");
	}
	
	private native void sayHello();
	
	public static void main(String[] args) throws Exception {
		new HelloJni().sayHello();
	}
}
