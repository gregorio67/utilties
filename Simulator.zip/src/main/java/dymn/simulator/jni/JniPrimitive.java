package dymn.simulator.jni;

public class JniPrimitive {

	static {
		System.loadLibrary("JniPrimitive");
		System.out.println("JniPrimitive is loaded");
	}
	
	private native double average(int n1, int n2);
	
	public static void main(String args[]) throws Exception {
		double avg = new JniPrimitive().average(4, 6);
		System.out.println("Average :: " + avg);
	}
}
