#include <jni.h>
#include "JniPrimitive.h"

JNIEXPORT jdouble JNICALL Java_dymn_simulator_jni_JniPrimitive_average (JNIEnv *env, jobject thisObject, jint n1, jint n2) {
        jdouble result = 0;

        result = ((jdouble) n1 + n2) / 2.0;

        return result;
}
