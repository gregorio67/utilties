$.fn.extend({
	selectRange: function(start, end) {
		if (!end) end = start;
		return this.each(function() {
			if (this.setSelectionRange) {
				this.focus();
				this.setSelectionRange(start, end);
			}
			else if (this.createTextRange) {
				var range = this.createTextRange();
				range.collapse(true);
				range.moveEnd('character', end);
				range.moveStart('character', start);
				range.select();
			}
		});
	}
	
})

$.fn.extend({
	getSelectedRange: function() {
		var el = this.get(0);
		start = 0;
		end = 0;
		
		if (el.selectionStart >= 0 && el.selectionEnd >= 0) {
			start = el.selectionStart;
			end = el.selectionEnd;
		}
		
		return {
			start: start,
			end: end
		}
	}
})


$.fn.extend({
	getSelectedValue: function() {
		var range = this.getSelectedRange();
		var val = this.val();
		return val.slice(range.start, range.end);
	}
})

$.fn.extend({
	clearSelection: function() {
		var el = this.get(0);
		start = 0;
		end = 0;
		this.val = "";
	}
})
