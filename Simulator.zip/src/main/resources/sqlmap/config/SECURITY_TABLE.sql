
drop table if exists SS_USERS

CREATE TABLE SS_USERS(
	username VARCHAR(50) NOT NULL,
	password VARCHAR(50) NOT NULL,
	enabled  SMALLINT NOT NULL DEFAULT 1, 
	PRIMARY key(username)
)

drop table if exists SS_USER_ROLES;

create TABLE SS_USER_ROLES( 
	user_role_id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
	username VARCHAR(50) NOT NULL,
	user_role VARCHAR(50) NOT NULL,
	constraint uni_username_role unique (user_role, username)
	CONSTRAINT fk_username FOREIGN key (username) REFERENCES ss_users(username)
)


insert into ss_users values('dykim', 'dykim', 1);
insert into ss_users values('test', 'test', 1);

insert into ss_user_roles values(null, 'dykim', "ROLE_ADMIN")
insert into ss_user_roles values(null, 'dykim', "ROLE_USER")
insert into ss_user_roles values(null, 'test', "ROLE_USER")

select * from ss_users;

select * from ss_user_roles;
