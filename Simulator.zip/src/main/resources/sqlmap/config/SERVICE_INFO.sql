DROP TABLE SERVICE_INFO;

CREATE TABLE SERVICE_INFO (   
   SERVICE_ID          BIGINT(10)  NOT NULL,
   SERVICE_NAME        VARCHAR(50) NOT NULL,
   TARGET_SERVICE_NAME VARCHAR(50)  NOT NULL,
   HEAD_INF_ID         VARCHAR(50) NOT NULL,
   MSG_INF_ID          VARCHAR(50) NOT NULL,
   HOST_ID             BIGINT(10) NOT NULL,
   RUN_THREAD_CNT      BIGINT(10),
   RUN_TIME_SECONDS	   BIGINT(10),	
   USE_YN  			   VARCHAR(1),
   constraint SERVICE_INFO_UN unique (SERVICE_ID)
 );
 
 
 INSERT INTO SERVICE_INFO VALUES (1, 'testService', '', 'HEADER_1', 'INF_USER', 1, 1, 60, 'Y');
insert into SERVICE_INFO values(2, 'sqlService', '', '', 'SQL_INFO', 2, 1, 60, 'Y');
insert into SERVICE_INFO values(3, 'dataSourceService', '', '', '', 3, 1, 60,'Y'); 

SELECT * from SERVICE_INFO;